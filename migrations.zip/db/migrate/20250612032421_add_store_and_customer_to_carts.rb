class AddStoreAndCustomerToCarts < ActiveRecord::Migration[8.0]
  def change
    add_reference :carts, :store, null: false, foreign_key: true
    # add_reference :carts, :customer, null: false, foreign_key: true
    
  end
end